import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="gpflow_lfm",
    version="0.0.1",
    author="Daniel Tait",
    author_email="daniel.tait@warwick.ac.uk",
    description="LFM in GPFlow",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/danieljtait/gpflow_lfm",
    packages=setuptools.find_packages(),
    classifiers=[
    "Programming Language :: Python :: 3",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    ],
    )
